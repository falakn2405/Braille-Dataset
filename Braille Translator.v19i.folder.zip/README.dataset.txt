# Braille Translator > 2023-07-17 12:43am
https://universe.roboflow.com/satwika-paul-tr5id/braille-translator

Provided by a Roboflow user
License: CC BY 4.0

