# more detailed braille > 2023-07-17 12:26am
https://universe.roboflow.com/satwika-paul-tr5id/more-detailed-braille

Provided by a Roboflow user
License: CC BY 4.0

