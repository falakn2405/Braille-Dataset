# braille > 2023-11-27 8:07pm
https://universe.roboflow.com/school-sdk3v/braille-ej8mc

Provided by a Roboflow user
License: CC BY 4.0

