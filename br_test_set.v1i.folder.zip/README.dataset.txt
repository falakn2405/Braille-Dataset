# br_test_set > 2023-12-04 1:38pm
https://universe.roboflow.com/thesisbraille-ft50v/br_test_set

Provided by a Roboflow user
License: CC BY 4.0

