# PNSB braille cell > 2023-12-04 10:58am
https://universe.roboflow.com/revision-thesis-braille/pnsb-braille-cell

Provided by a Roboflow user
License: CC BY 4.0

