# braille_cell_2 > 2023-12-03 1:37pm
https://universe.roboflow.com/thesisbraille-ft50v/braille_cell_2

Provided by a Roboflow user
License: CC BY 4.0

