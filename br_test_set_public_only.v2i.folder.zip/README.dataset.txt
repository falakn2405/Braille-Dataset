# br_test_set_public_only > 2023-12-04 1:35pm
https://universe.roboflow.com/thesisbraille-ft50v/br_test_set_public_only

Provided by a Roboflow user
License: CC BY 4.0

