# kp_braille > 2022-08-10 12:33pm
https://universe.roboflow.com/praktek-braille/kp_braille

Provided by a Roboflow user
License: CC BY 4.0

